"""An amazing sample package!"""

__version__ = '0.3'

__all__ = ["ModelBuilder", "Ingredient"]